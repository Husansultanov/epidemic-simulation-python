# -*- coding: utf-8 -*-
"""
main.py
=======
Жобаның кіру нүктесі. Осы файлды іске қосу арқылы толық қосымша
ашылады: `python main.py`

Точка входа в проект. Запуск этого файла открывает полное
приложение: `python main.py`

The project's entry point. Running this file opens the full
application: `python main.py`
"""

from gui import launch_app


def main() -> None:
    """
    Қосымшаны бастайтын негізгі функция.
    Главная функция, запускающая приложение.
    Main function that starts the application.
    """
    launch_app()


if __name__ == "__main__":
    main()
