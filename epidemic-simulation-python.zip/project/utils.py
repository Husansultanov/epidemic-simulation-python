# -*- coding: utf-8 -*-
"""
utils.py
========
Көмекші функциялар және көптілді (KZ / RU / EN) мәтіндер сөздігі.
Вспомогательные функции и словарь многоязычных (KZ / RU / EN) текстов.
Helper functions and the multilingual (KZ / RU / EN) text dictionary.

Бұл модуль интерфейстің барлық мәтіндерін бір жерде сақтайды, сол арқылы
GUI-де тілді ауыстырғанда тек осы сөздікке жүгіну жеткілікті болады.

Этот модуль хранит все тексты интерфейса в одном месте, поэтому при
переключении языка в GUI достаточно обращаться только к этому словарю.

This module keeps every interface string in one place so that switching
the language in the GUI only requires looking values up here.
"""

from __future__ import annotations
from typing import Any


# ---------------------------------------------------------------------------
# Тіл кодтары / Коды языков / Language codes
# ---------------------------------------------------------------------------
LANG_KZ = "KZ"
LANG_RU = "RU"
LANG_EN = "EN"

LANGUAGES = [LANG_KZ, LANG_RU, LANG_EN]


# ---------------------------------------------------------------------------
# Көптілді сөздік / Многоязычный словарь / Multilingual dictionary
# ---------------------------------------------------------------------------
TEXTS: dict[str, dict[str, str]] = {
    # ---- Терезе тақырыбы / заголовок окна / window title -----------------
    "app_title": {
        LANG_KZ: "Жұқпалы аурулардың таралуын компьютерлік модельдеу (SIR моделі)",
        LANG_RU: "Компьютерное моделирование распространения инфекционных заболеваний (SIR-модель)",
        LANG_EN: "Computer Simulation of Infectious Disease Spread (SIR Model)",
    },
    "header": {
        LANG_KZ: "SIR ЭПИДЕМИОЛОГИЯЛЫҚ МОДЕЛІ",
        LANG_RU: "SIR ЭПИДЕМИОЛОГИЧЕСКАЯ МОДЕЛЬ",
        LANG_EN: "SIR EPIDEMIOLOGICAL MODEL",
    },

    # ---- Параметрлер панелі / панель параметров / parameters panel -------
    "params_frame": {
        LANG_KZ: "Модель параметрлері",
        LANG_RU: "Параметры модели",
        LANG_EN: "Model Parameters",
    },
    "population": {
        LANG_KZ: "Халық саны (N)",
        LANG_RU: "Численность населения (N)",
        LANG_EN: "Population size (N)",
    },
    "initial_infected": {
        LANG_KZ: "Бастапқы жұқтырғандар саны (I0)",
        LANG_RU: "Начальное число заражённых (I0)",
        LANG_EN: "Initial number of infected (I0)",
    },
    "beta": {
        LANG_KZ: "Жұқтыру коэффициенті (β)",
        LANG_RU: "Коэффициент заражения (β)",
        LANG_EN: "Infection rate (β)",
    },
    "gamma": {
        LANG_KZ: "Жазылу коэффициенті (γ)",
        LANG_RU: "Коэффициент выздоровления (γ)",
        LANG_EN: "Recovery rate (γ)",
    },
    "vaccination_pct": {
        LANG_KZ: "Вакцинация пайызы (%)",
        LANG_RU: "Процент вакцинации (%)",
        LANG_EN: "Vaccination percentage (%)",
    },
    "quarantine_eff": {
        LANG_KZ: "Карантин тиімділігі (%)",
        LANG_RU: "Эффективность карантина (%)",
        LANG_EN: "Quarantine efficiency (%)",
    },
    "days": {
        LANG_KZ: "Модельдеу ұзақтығы (күн)",
        LANG_RU: "Длительность моделирования (дней)",
        LANG_EN: "Simulation duration (days)",
    },

    # ---- Батырмалар / кнопки / buttons ------------------------------------
    "btn_simulate": {
        LANG_KZ: "▶ Модельдеу",
        LANG_RU: "▶ Запустить моделирование",
        LANG_EN: "▶ Run Simulation",
    },
    "btn_clear": {
        LANG_KZ: "✕ Нәтижелерді тазарту",
        LANG_RU: "✕ Очистить результаты",
        LANG_EN: "✕ Clear Results",
    },
    "btn_save": {
        LANG_KZ: "💾 Графикті сақтау",
        LANG_RU: "💾 Сохранить графики",
        LANG_EN: "💾 Save Graphs",
    },
    "language": {
        LANG_KZ: "Тіл",
        LANG_RU: "Язык",
        LANG_EN: "Language",
    },

    # ---- Нәтижелер панелі / панель результатов / results panel -----------
    "results_frame": {
        LANG_KZ: "Модельдеу нәтижелері",
        LANG_RU: "Результаты моделирования",
        LANG_EN: "Simulation Results",
    },
    "peak_infected": {
        LANG_KZ: "Жұқтырғандар саны бойынша шыңы (пик)",
        LANG_RU: "Пик заражения (максимум I)",
        LANG_EN: "Infection peak (max I)",
    },
    "peak_day": {
        LANG_KZ: "Максималды жұқтыру күні",
        LANG_RU: "День максимального заражения",
        LANG_EN: "Day of maximum infection",
    },
    "recovered_count": {
        LANG_KZ: "Жазылғандар саны",
        LANG_RU: "Количество выздоровевших",
        LANG_EN: "Number recovered",
    },
    "healthy_count": {
        LANG_KZ: "Сау адамдар саны",
        LANG_RU: "Количество здоровых (не заболевших)",
        LANG_EN: "Number of healthy (never infected)",
    },
    "infected_pct": {
        LANG_KZ: "Ауырғандардың пайызы",
        LANG_RU: "Процент заболевших",
        LANG_EN: "Percentage infected",
    },
    "recovered_pct": {
        LANG_KZ: "Жазылғандардың пайызы",
        LANG_RU: "Процент выздоровевших",
        LANG_EN: "Percentage recovered",
    },
    "r0_value": {
        LANG_KZ: "Негізгі репродукциялық сан (R0)",
        LANG_RU: "Базовое репродуктивное число (R0)",
        LANG_EN: "Basic reproduction number (R0)",
    },

    # ---- Графиктер қойындылары / вкладки графиков / graph tabs -----------
    "tab_main": {
        LANG_KZ: "S(t), I(t), R(t) графигі",
        LANG_RU: "Графики S(t), I(t), R(t)",
        LANG_EN: "S(t), I(t), R(t) Graphs",
    },
    "tab_compare": {
        LANG_KZ: "Сценарийлерді салыстыру",
        LANG_RU: "Сравнение сценариев",
        LANG_EN: "Scenario Comparison",
    },

    # ---- Сценарий атаулары / названия сценариев / scenario names ---------
    "scenario_normal": {
        LANG_KZ: "Шектеусіз сценарий",
        LANG_RU: "Обычный сценарий (без ограничений)",
        LANG_EN: "Baseline scenario (no interventions)",
    },
    "scenario_quarantine": {
        LANG_KZ: "Карантин сценарийі",
        LANG_RU: "Сценарий с карантином",
        LANG_EN: "Quarantine scenario",
    },
    "scenario_vaccination": {
        LANG_KZ: "Вакцинация сценарийі",
        LANG_RU: "Сценарий с вакцинацией",
        LANG_EN: "Vaccination scenario",
    },

    # ---- Осьтер мен тақырыптар / оси и заголовки / axes & titles ---------
    "days_axis": {
        LANG_KZ: "Күндер",
        LANG_RU: "Дни",
        LANG_EN: "Days",
    },
    "people_axis": {
        LANG_KZ: "Адам саны",
        LANG_RU: "Число людей",
        LANG_EN: "Number of people",
    },
    "susceptible_label": {
        LANG_KZ: "S(t) — Сезімтал (әлі ауырмаған)",
        LANG_RU: "S(t) — Восприимчивые",
        LANG_EN: "S(t) — Susceptible",
    },
    "infected_label": {
        LANG_KZ: "I(t) — Жұқтырғандар",
        LANG_RU: "I(t) — Заражённые",
        LANG_EN: "I(t) — Infected",
    },
    "recovered_label": {
        LANG_KZ: "R(t) — Жазылғандар",
        LANG_RU: "R(t) — Выздоровевшие",
        LANG_EN: "R(t) — Recovered",
    },
    "comparison_title": {
        LANG_KZ: "Жұқтырғандар санының сценарийлер бойынша салыстыруы I(t)",
        LANG_RU: "Сравнение числа заражённых I(t) по сценариям",
        LANG_EN: "Comparison of infected I(t) across scenarios",
    },
    "main_title": {
        LANG_KZ: "SIR моделі: S(t), I(t), R(t) динамикасы",
        LANG_RU: "SIR-модель: динамика S(t), I(t), R(t)",
        LANG_EN: "SIR Model: dynamics of S(t), I(t), R(t)",
    },

    # ---- Хабарламалар / сообщения / messages ------------------------------
    "error_title": {
        LANG_KZ: "Қате",
        LANG_RU: "Ошибка",
        LANG_EN: "Error",
    },
    "error_invalid_input": {
        LANG_KZ: "Барлық параметрлерді дұрыс сандық мәндермен толтырыңыз.",
        LANG_RU: "Заполните все параметры корректными числовыми значениями.",
        LANG_EN: "Please fill in all parameters with valid numeric values.",
    },
    "error_no_data": {
        LANG_KZ: "Сақтау үшін алдымен модельдеуді іске қосыңыз.",
        LANG_RU: "Сначала запустите моделирование, чтобы было что сохранять.",
        LANG_EN: "Run the simulation first before saving.",
    },
    "info_title": {
        LANG_KZ: "Ақпарат",
        LANG_RU: "Информация",
        LANG_EN: "Information",
    },
    "saved_ok": {
        LANG_KZ: "Графиктер сәтті сақталды:",
        LANG_RU: "Графики успешно сохранены:",
        LANG_EN: "Graphs saved successfully to:",
    },
    "status_ready": {
        LANG_KZ: "Дайын",
        LANG_RU: "Готово",
        LANG_EN: "Ready",
    },
    "status_running": {
        LANG_KZ: "Есептеу орындалуда...",
        LANG_RU: "Выполняется расчёт...",
        LANG_EN: "Computing...",
    },
    "status_done": {
        LANG_KZ: "Модельдеу аяқталды",
        LANG_RU: "Моделирование завершено",
        LANG_EN: "Simulation completed",
    },
    "status_cleared": {
        LANG_KZ: "Нәтижелер тазартылды",
        LANG_RU: "Результаты очищены",
        LANG_EN: "Results cleared",
    },
    "footer": {
        LANG_KZ: "Компьютерлік модельдеу пәні | SIR моделі | Python 3",
        LANG_RU: "Дисциплина «Компьютерное моделирование» | SIR-модель | Python 3",
        LANG_EN: "Computer Modeling Course | SIR Model | Python 3",
    },
}


def t(key: str, lang: str) -> str:
    """
    Берілген кілт пен тіл үшін аударманы қайтарады.
    Возвращает перевод для заданного ключа и языка.
    Returns the translated string for the given key and language.

    Аударма табылмаса, кілттің өзі қайтарылады (қорғаныс тәсілі).
    Если перевод не найден, возвращается сам ключ (защитный вариант).
    If the translation is missing, the key itself is returned as a fallback.
    """
    entry = TEXTS.get(key)
    if entry is None:
        return key
    return entry.get(lang, entry.get(LANG_RU, key))


def safe_float(value: Any, default: float = 0.0) -> float:
    """
    Мәтінді қауіпсіз түрде float-қа түрлендіреді.
    Безопасно преобразует строку в float.
    Safely converts a string to a float, returning `default` on failure.
    """
    try:
        return float(str(value).replace(",", "."))
    except (ValueError, TypeError):
        return default


def safe_int(value: Any, default: int = 0) -> int:
    """
    Мәтінді қауіпсіз түрде int-ке түрлендіреді.
    Безопасно преобразует строку в int.
    Safely converts a string to an int, returning `default` on failure.
    """
    try:
        return int(float(str(value).replace(",", ".")))
    except (ValueError, TypeError):
        return default


def validate_positive(*values: float) -> bool:
    """
    Барлық мәндердің оң екенін тексереді.
    Проверяет, что все значения положительны.
    Checks that every value provided is strictly positive.
    """
    return all(v > 0 for v in values)
