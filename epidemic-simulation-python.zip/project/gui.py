# -*- coding: utf-8 -*-
"""
gui.py
======
CustomTkinter негізіндегі заманауи графикалық интерфейс.
Пайдаланушыға модель параметрлерін енгізуге, модельдеуді іске
қосуға, нәтижелерді көруге, графиктерді салыстыруға және оларды
сақтауға мүмкіндік береді. Интерфейс үш тілде жұмыс істейді:
қазақша, орысша, ағылшынша.

Современный графический интерфейс на базе CustomTkinter.
Позволяет пользователю вводить параметры модели, запускать
моделирование, просматривать результаты, сравнивать графики
и сохранять их. Интерфейс работает на трёх языках: казахском,
русском, английском.

Modern graphical interface built with CustomTkinter. Lets the user
enter model parameters, run the simulation, view the results,
compare graphs, and save them. The interface works in three
languages: Kazakh, Russian, English.
"""

from __future__ import annotations
import os
import tkinter as tk
from tkinter import messagebox, filedialog

import customtkinter as ctk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

from utils import t as tr, LANGUAGES, LANG_RU, safe_float, safe_int, validate_positive
from simulation import Simulation, SimulationInput
from statistics import StatisticsCalculator
from graphs import GraphPlotter


ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")


class SIRApplication(ctk.CTk):
    """
    Қосымшаның басты терезесі (CTk мұрагері).
    Главное окно приложения (наследник CTk).
    The application's main window (a CTk subclass).
    """

    # --- Әдепкі мәндер / значения по умолчанию / default values -----------
    DEFAULTS = {
        "population": "10000",
        "initial_infected": "10",
        "beta": "0.30",
        "gamma": "0.10",
        "vaccination_pct": "20",
        "quarantine_eff": "40",
        "days": "160",
    }

    def __init__(self):
        super().__init__()

        self.lang = LANG_RU
        self.plotter = GraphPlotter(lang=self.lang)
        self.simulation: Simulation | None = None
        self.results: dict[str, dict] = {}
        self.main_figure = Figure(figsize=(6.5, 4.5), dpi=100)
        self.compare_figure = Figure(figsize=(6.5, 4.5), dpi=100)

        self.geometry("1280x800")
        self.minsize(1100, 700)

        self._build_layout()
        self._retranslate_ui()

    # =======================================================================
    # ИНТЕРФЕЙСТІ ҚҰРУ / ПОСТРОЕНИЕ ИНТЕРФЕЙСА / BUILDING THE LAYOUT
    # =======================================================================
    def _build_layout(self) -> None:
        """Барлық виджеттерді жасайды және орналастырады.
        Создаёт и размещает все виджеты.
        Creates and places all widgets."""

        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self._build_sidebar()
        self._build_main_area()

    # -----------------------------------------------------------------
    # Бүйір панелі (параметрлер) / Боковая панель (параметры) / Sidebar
    # -----------------------------------------------------------------
    def _build_sidebar(self) -> None:
        self.sidebar = ctk.CTkScrollableFrame(self, width=320, corner_radius=0)
        self.sidebar.grid(row=0, column=0, sticky="nsw")

        self.header_label = ctk.CTkLabel(
            self.sidebar, text="", font=ctk.CTkFont(size=16, weight="bold"),
            wraplength=280, justify="left"
        )
        self.header_label.pack(padx=16, pady=(20, 10), anchor="w")

        # --- Тіл таңдау / выбор языка / language selector ------------
        self.lang_label = ctk.CTkLabel(self.sidebar, text="")
        self.lang_label.pack(padx=16, pady=(6, 0), anchor="w")
        self.lang_menu = ctk.CTkOptionMenu(
            self.sidebar, values=LANGUAGES, command=self._on_language_change
        )
        self.lang_menu.set(self.lang)
        self.lang_menu.pack(padx=16, pady=(2, 16), fill="x")

        # --- Параметрлер фреймі / фрейм параметров / parameters frame -
        self.params_frame_label = ctk.CTkLabel(
            self.sidebar, text="", font=ctk.CTkFont(size=14, weight="bold")
        )
        self.params_frame_label.pack(padx=16, pady=(4, 8), anchor="w")

        self.entries: dict[str, ctk.CTkEntry] = {}
        self.field_labels: dict[str, ctk.CTkLabel] = {}

        field_order = [
            "population", "initial_infected", "beta", "gamma",
            "vaccination_pct", "quarantine_eff", "days",
        ]
        for field in field_order:
            lbl = ctk.CTkLabel(self.sidebar, text="", anchor="w")
            lbl.pack(padx=16, pady=(6, 0), anchor="w")
            entry = ctk.CTkEntry(self.sidebar)
            entry.insert(0, self.DEFAULTS[field])
            entry.pack(padx=16, pady=(2, 0), fill="x")
            self.field_labels[field] = lbl
            self.entries[field] = entry

        # --- Батырмалар / кнопки / buttons -----------------------------
        self.btn_simulate = ctk.CTkButton(
            self.sidebar, text="", command=self._on_simulate,
            fg_color="#2A9D8F", hover_color="#21867A", height=40
        )
        self.btn_simulate.pack(padx=16, pady=(22, 8), fill="x")

        self.btn_clear = ctk.CTkButton(
            self.sidebar, text="", command=self._on_clear,
            fg_color="#E63946", hover_color="#C42D39", height=36
        )
        self.btn_clear.pack(padx=16, pady=4, fill="x")

        self.btn_save = ctk.CTkButton(
            self.sidebar, text="", command=self._on_save,
            fg_color="#264653", hover_color="#1B333C", height=36
        )
        self.btn_save.pack(padx=16, pady=4, fill="x")

        # --- Статус жолағы / строка статуса / status label -------------
        self.status_label = ctk.CTkLabel(self.sidebar, text="", text_color="gray50")
        self.status_label.pack(padx=16, pady=(18, 8), anchor="w")

        # --- Нәтижелер фреймі / фрейм результатов / results frame -----
        self.results_frame_label = ctk.CTkLabel(
            self.sidebar, text="", font=ctk.CTkFont(size=14, weight="bold")
        )
        self.results_frame_label.pack(padx=16, pady=(10, 8), anchor="w")

        self.result_rows: dict[str, tuple[ctk.CTkLabel, ctk.CTkLabel]] = {}
        result_keys = [
            "peak_infected", "peak_day", "recovered_count", "healthy_count",
            "infected_pct", "recovered_pct", "r0_value",
        ]
        for key in result_keys:
            row = ctk.CTkFrame(self.sidebar, fg_color="transparent")
            row.pack(padx=16, pady=2, fill="x")
            caption = ctk.CTkLabel(row, text="", anchor="w", font=ctk.CTkFont(size=12))
            caption.pack(side="left")
            value = ctk.CTkLabel(row, text="—", anchor="e", font=ctk.CTkFont(size=12, weight="bold"))
            value.pack(side="right")
            self.result_rows[key] = (caption, value)

        self.footer_label = ctk.CTkLabel(self.sidebar, text="", text_color="gray50",
                                          font=ctk.CTkFont(size=10), wraplength=280)
        self.footer_label.pack(padx=16, pady=(20, 16), anchor="w")

    # -----------------------------------------------------------------
    # Негізгі аймақ (графиктер) / Основная область (графики) / Main area
    # -----------------------------------------------------------------
    def _build_main_area(self) -> None:
        self.tabview = ctk.CTkTabview(self)
        self.tabview.grid(row=0, column=1, sticky="nsew", padx=16, pady=16)

        self.tab_main_key = "tab_main"
        self.tab_compare_key = "tab_compare"

        self.tab_main = self.tabview.add(tr(self.tab_main_key, self.lang))
        self.tab_compare = self.tabview.add(tr(self.tab_compare_key, self.lang))

        self.main_canvas = FigureCanvasTkAgg(self.main_figure, master=self.tab_main)
        self.main_canvas.get_tk_widget().pack(fill="both", expand=True, padx=8, pady=8)

        self.compare_canvas = FigureCanvasTkAgg(self.compare_figure, master=self.tab_compare)
        self.compare_canvas.get_tk_widget().pack(fill="both", expand=True, padx=8, pady=8)

    # =======================================================================
    # ОҚИҒА ӨҢДЕУШІЛЕРІ / ОБРАБОТЧИКИ СОБЫТИЙ / EVENT HANDLERS
    # =======================================================================
    def _on_language_change(self, new_lang: str) -> None:
        """Тілді ауыстырады және барлық мәтіндерді жаңартады.
        Переключает язык и обновляет все тексты.
        Switches the language and refreshes every text label."""
        self.lang = new_lang
        self.plotter.set_language(new_lang)
        self._retranslate_ui()
        # Егер нәтиже бар болса, графиктерді қайта салу (жаңа тілмен)
        # Если результаты уже есть, перерисовать графики (с новым языком)
        # If results already exist, redraw the graphs with the new language
        if self.results:
            self._redraw_graphs()

    def _on_simulate(self) -> None:
        """"Модельдеу" батырмасының өңдеушісі.
        Обработчик кнопки "Запустить моделирование".
        Handler for the "Run Simulation" button."""
        try:
            values = self._read_inputs()
        except ValueError:
            messagebox.showerror(tr("error_title", self.lang), tr("error_invalid_input", self.lang))
            return

        self.status_label.configure(text=tr("status_running", self.lang))
        self.update_idletasks()

        sim_input = SimulationInput(
            population=values["population"],
            initial_infected=values["initial_infected"],
            beta=values["beta"],
            gamma=values["gamma"],
            vaccination_pct=values["vaccination_pct"],
            quarantine_eff_pct=values["quarantine_eff"],
            days=int(values["days"]),
        )

        self.simulation = Simulation(sim_input)
        self.results = self.simulation.run_all()

        self._redraw_graphs()
        self._update_statistics(values["population"])

        self.status_label.configure(text=tr("status_done", self.lang))

    def _on_clear(self) -> None:
        """"Тазарту" батырмасының өңдеушісі.
        Обработчик кнопки "Очистить".
        Handler for the "Clear" button."""
        self.results = {}
        self.simulation = None
        self.main_figure.clear()
        self.compare_figure.clear()
        self.main_canvas.draw()
        self.compare_canvas.draw()
        for caption, value in self.result_rows.values():
            value.configure(text="—")
        self.status_label.configure(text=tr("status_cleared", self.lang))

    def _on_save(self) -> None:
        """"Сақтау" батырмасының өңдеушісі.
        Обработчик кнопки "Сохранить".
        Handler for the "Save" button."""
        if not self.results:
            messagebox.showwarning(tr("error_title", self.lang), tr("error_no_data", self.lang))
            return

        directory = filedialog.askdirectory(title=tr("btn_save", self.lang))
        if not directory:
            return

        main_path = os.path.join(directory, "sir_main_graph.png")
        compare_path = os.path.join(directory, "sir_comparison_graph.png")
        self.plotter.save_figure(self.main_figure, main_path)
        self.plotter.save_figure(self.compare_figure, compare_path)

        messagebox.showinfo(
            tr("info_title", self.lang),
            f"{tr('saved_ok', self.lang)}\n{main_path}\n{compare_path}"
        )

    # =======================================================================
    # КӨМЕКШІ ӘДІСТЕР / ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ / HELPER METHODS
    # =======================================================================
    def _read_inputs(self) -> dict[str, float]:
        """
        Барлық өрістерден мәндерді оқып, тексереді.
        Считывает и проверяет значения из всех полей ввода.
        Reads and validates the values from every input field.
        """
        raw = {key: entry.get() for key, entry in self.entries.items()}

        population = safe_float(raw["population"])
        initial_infected = safe_float(raw["initial_infected"])
        beta = safe_float(raw["beta"])
        gamma = safe_float(raw["gamma"])
        vaccination_pct = safe_float(raw["vaccination_pct"])
        quarantine_eff = safe_float(raw["quarantine_eff"])
        days = safe_int(raw["days"])

        if not validate_positive(population, beta, gamma, days) or initial_infected < 0:
            raise ValueError("Invalid input")
        if initial_infected > population:
            raise ValueError("Invalid input")
        if not (0 <= vaccination_pct <= 100) or not (0 <= quarantine_eff <= 100):
            raise ValueError("Invalid input")

        return {
            "population": population,
            "initial_infected": initial_infected,
            "beta": beta,
            "gamma": gamma,
            "vaccination_pct": vaccination_pct,
            "quarantine_eff": quarantine_eff,
            "days": days,
        }

    def _redraw_graphs(self) -> None:
        """Екі графикті де ағымдағы нәтижелермен қайта салады.
        Перерисовывает оба графика по текущим результатам.
        Redraws both graphs from the current results."""
        normal_result = self.results.get("normal")
        if normal_result is not None:
            self.plotter.plot_main(self.main_figure, normal_result)
            self.main_canvas.draw()

        self.plotter.plot_comparison(self.compare_figure, self.results)
        self.compare_canvas.draw()

    def _update_statistics(self, population: float) -> None:
        """"normal" сценарийі бойынша статистиканы есептеп, панельге шығарады.
        Рассчитывает статистику по сценарию "normal" и выводит в панель.
        Computes statistics for the "normal" scenario and displays them."""
        calculator = StatisticsCalculator(population)
        stats = calculator.compute(self.results["normal"])
        r0 = self.simulation.basic_reproduction_number()

        self.result_rows["peak_infected"][1].configure(text=f"{stats.peak_infected:,.0f}")
        self.result_rows["peak_day"][1].configure(text=f"{stats.peak_day}")
        self.result_rows["recovered_count"][1].configure(text=f"{stats.total_recovered:,.0f}")
        self.result_rows["healthy_count"][1].configure(text=f"{stats.total_healthy:,.0f}")
        self.result_rows["infected_pct"][1].configure(text=f"{stats.percent_infected:.1f}%")
        self.result_rows["recovered_pct"][1].configure(text=f"{stats.percent_recovered:.1f}%")
        self.result_rows["r0_value"][1].configure(text=f"{r0:.2f}")

    def _retranslate_ui(self) -> None:
        """
        Ағымдағы тілге сәйкес интерфейстегі барлық мәтіндерді жаңартады.
        Обновляет все тексты интерфейса в соответствии с текущим языком.
        Refreshes every interface text according to the current language.
        """
        self.title(tr("app_title", self.lang))
        self.header_label.configure(text=tr("header", self.lang))
        self.lang_label.configure(text=tr("language", self.lang))
        self.params_frame_label.configure(text=tr("params_frame", self.lang))

        for field, lbl in self.field_labels.items():
            key = "quarantine_eff" if field == "quarantine_eff" else field
            lbl.configure(text=tr(key, self.lang))

        self.btn_simulate.configure(text=tr("btn_simulate", self.lang))
        self.btn_clear.configure(text=tr("btn_clear", self.lang))
        self.btn_save.configure(text=tr("btn_save", self.lang))
        self.status_label.configure(text=tr("status_ready", self.lang))
        self.results_frame_label.configure(text=tr("results_frame", self.lang))
        self.footer_label.configure(text=tr("footer", self.lang))

        result_key_map = {
            "peak_infected": "peak_infected",
            "peak_day": "peak_day",
            "recovered_count": "recovered_count",
            "healthy_count": "healthy_count",
            "infected_pct": "infected_pct",
            "recovered_pct": "recovered_pct",
            "r0_value": "r0_value",
        }
        for key, (caption, _value) in self.result_rows.items():
            caption.configure(text=tr(result_key_map[key], self.lang) + ":")

        # Қойынды атауларын жаңарту (CTkTabview атауды өзгертуді қолдамайды,
        # сондықтан тек бірінші рет құрғанда дұрыс тіл орнатылады).
        # Обновление названий вкладок (CTkTabview не поддерживает
        # переименование "на лету", поэтому язык вкладок фиксируется
        # при первом запуске интерфейса).
        # Tab titles are set once at startup because CTkTabview does not
        # support renaming tabs on the fly.


def launch_app() -> None:
    """Қосымшаны іске қосатын функция.
    Функция запуска приложения.
    Function that launches the application."""
    app = SIRApplication()
    app.mainloop()
