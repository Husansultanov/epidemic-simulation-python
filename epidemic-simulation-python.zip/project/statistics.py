# -*- coding: utf-8 -*-
"""
statistics.py
=============
Модельдеу нәтижелері бойынша статистикалық көрсеткіштерді есептейтін
модуль: жұқтыру шыңы, шың күні, жазылғандар саны, сау адамдар саны,
ауырғандар мен жазылғандардың пайызы.

Модуль для расчёта статистических показателей по результатам
моделирования: пик заражения, день пика, число выздоровевших,
число здоровых, проценты заболевших и выздоровевших.

Module that computes statistical indicators from the simulation
results: infection peak, day of the peak, number recovered, number
healthy, percentage infected, percentage recovered.
"""

from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import pandas as pd


@dataclass
class EpidemicStatistics:
    """
    Есептелген статистикалық көрсеткіштерді сақтайтын dataclass.
    Dataclass, хранящий рассчитанные статистические показатели.
    Dataclass holding the computed statistical indicators.
    """
    peak_infected: float          # жұқтыру шыңы / пик заражения / infection peak
    peak_day: int                 # шың күні / день пика / day of the peak
    total_recovered: float        # барлық жазылғандар / всего выздоровело / total recovered
    total_healthy: float          # соңында сау қалғандар / здоровы в конце / healthy at the end
    percent_infected: float       # ауырғандар пайызы / % заболевших / % infected
    percent_recovered: float      # жазылғандар пайызы / % выздоровевших / % recovered


class StatisticsCalculator:
    """
    Бір сценарийдің SIR нәтижесінен статистика есептейтін класс.
    Класс для расчёта статистики по результату SIR для одного сценария.
    Class that computes statistics from a single scenario's SIR result.
    """

    def __init__(self, population: float):
        self.population = population

    def compute(self, sir_result: dict) -> EpidemicStatistics:
        """
        SIRModel.simulate() нәтижесі бойынша толық статистиканы құрады.
        Строит полную статистику по результату SIRModel.simulate().
        Builds full statistics from the output of SIRModel.simulate().
        """
        t = sir_result["t"]
        s = sir_result["S"]
        i = sir_result["I"]
        r = sir_result["R"]

        # --- Жұқтыру шыңы және оның күні ---------------------------------
        # --- Пик заражения и его день ------------------------------------
        # --- Infection peak and the day it occurs ------------------------
        peak_idx = int(np.argmax(i))
        peak_infected = float(i[peak_idx])
        peak_day = int(t[peak_idx])

        # --- Соңғы мәндер бойынша қорытынды көрсеткіштер -----------------
        # --- Итоговые показатели по последним значениям ------------------
        # --- Final indicators based on the last time step -----------------
        total_recovered = float(r[-1])
        total_healthy = float(s[-1])

        # Ешқашан ауырмаған адамдар - соңғы S(t). Демек, "ауырғандар" -
        # барлық халықтың сол сан алынған үлесі.
        # Никогда не болевшие - это последнее значение S(t). Значит,
        # "переболевшие" - это оставшаяся доля от всего населения.
        # Those never infected correspond to the final S(t) value, so the
        # "ever infected" share is the remaining fraction of the population.
        ever_infected = self.population - total_healthy
        percent_infected = (ever_infected / self.population) * 100.0 if self.population else 0.0
        percent_recovered = (total_recovered / self.population) * 100.0 if self.population else 0.0

        return EpidemicStatistics(
            peak_infected=peak_infected,
            peak_day=peak_day,
            total_recovered=total_recovered,
            total_healthy=total_healthy,
            percent_infected=percent_infected,
            percent_recovered=percent_recovered,
        )

    @staticmethod
    def to_dataframe(sir_result: dict) -> pd.DataFrame:
        """
        SIR нәтижесін pandas.DataFrame форматына түрлендіреді
        (кестелік талдау немесе CSV экспорты үшін ыңғайлы).

        Преобразует результат SIR в pandas.DataFrame (удобно для
        табличного анализа или экспорта в CSV).

        Converts a SIR result into a pandas.DataFrame (convenient
        for tabular analysis or CSV export).
        """
        return pd.DataFrame({
            "day": sir_result["t"],
            "S": sir_result["S"],
            "I": sir_result["I"],
            "R": sir_result["R"],
        })
