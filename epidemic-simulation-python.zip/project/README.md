# SIR моделі — Жұқпалы аурулардың таралуын компьютерлік модельдеу
# SIR-модель — Компьютерное моделирование распространения инфекционных заболеваний
# SIR Model — Computer Simulation of Infectious Disease Spread

Университеттік экзаменациялық жоба | Курсовой / экзаменационный университетский проект | University exam project
**Пән / Дисциплина / Course:** Компьютерлік модельдеу (Компьютерное моделирование)

---

## 🇰🇿 Қазақша

### Жоба туралы
Бұл жоба SIR (Susceptible–Infected–Recovered) эпидемиологиялық моделін
Python тілінде объектіге бағытталған бағдарламалау (ООП) қағидаттарымен
іске асырады. Қосымша үш сценарийді салыстыруға мүмкіндік береді:
шектеусіз тарату, карантинмен және вакцинациямен.

### Файл құрылымы
```
project/
├── main.py          — жобаны іске қосатын кіру нүктесі
├── gui.py           — CustomTkinter графикалық интерфейсі
├── sir_model.py      — SIR дифференциалдық теңдеулер жүйесі (scipy)
├── simulation.py     — үш сценарийді басқаратын модуль
├── graphs.py         — matplotlib графиктері
├── statistics.py     — статистикалық көрсеткіштерді есептеу
├── utils.py          — үш тілді сөздік және көмекші функциялар
├── assets/           — қосымша ресурстар (иконкалар және т.б.)
└── README.md         — осы файл
```

### Орнату
```bash
pip install numpy scipy matplotlib pandas customtkinter
```
> Ескерту: `tkinter` көбіне Python-мен бірге келеді. Егер жоқ болса,
> Linux-та: `sudo apt-get install python3-tk`

### Іске қосу
```bash
python main.py
```

### Мүмкіндіктер
- Халық санын, бастапқы жұқтырғандар санын, β және γ коэффициенттерін,
  вакцинация пайызын, карантин тиімділігін және модельдеу ұзақтығын енгізу;
- «Модельдеу» батырмасымен есептеуді іске қосу;
- «Нәтижелерді тазарту» батырмасы;
- Графиктерді PNG форматында сақтау;
- Жұқтыру шыңы, шың күні, жазылғандар, сау адамдар, ауырғандар мен
  жазылғандардың пайызы, R0 көрсетілуі;
- S(t)/I(t)/R(t) графигі және үш сценарийді салыстыру графигі;
- Интерфейс тілін қазақша/орысша/ағылшынша ауыстыру.

---

## 🇷🇺 Русский

### О проекте
Проект реализует эпидемиологическую SIR-модель (Susceptible–Infected–
Recovered) на Python с использованием объектно-ориентированного
подхода (ООП). Приложение позволяет сравнить три сценария:
без ограничений, с карантином и с вакцинацией.

### Структура файлов
```
project/
├── main.py          — точка входа, запускающая приложение
├── gui.py           — графический интерфейс на CustomTkinter
├── sir_model.py      — система дифференциальных уравнений SIR (scipy)
├── simulation.py     — модуль, управляющий тремя сценариями
├── graphs.py         — построение графиков через matplotlib
├── statistics.py     — расчёт статистических показателей
├── utils.py          — трёхъязычный словарь и вспомогательные функции
├── assets/           — дополнительные ресурсы (иконки и т.д.)
└── README.md         — этот файл
```

### Установка зависимостей
```bash
pip install numpy scipy matplotlib pandas customtkinter
```
> Примечание: `tkinter` обычно идёт в комплекте с Python. Если его нет —
> на Linux: `sudo apt-get install python3-tk`

### Запуск
```bash
python main.py
```

### Возможности
- Ввод численности населения, начального числа заражённых,
  коэффициентов β и γ, процента вакцинации, эффективности карантина
  и длительности моделирования;
- Запуск расчёта кнопкой «Запустить моделирование»;
- Кнопка «Очистить результаты»;
- Сохранение графиков в формате PNG;
- Вывод пика заражения, дня пика, числа выздоровевших, числа здоровых,
  процента заболевших и выздоровевших, значения R0;
- График S(t)/I(t)/R(t) и график сравнения трёх сценариев;
- Переключение языка интерфейса: казахский / русский / английский.

### Математическая модель (кратко)
Классическая SIR-модель Кермака–МакКендрика описывается системой:

```
dS/dt = -β·S·I/N
dI/dt =  β·S·I/N - γ·I
dR/dt =  γ·I
```

где N — численность населения, β — коэффициент заражения,
γ — коэффициент выздоровления, R0 = β/γ — базовое репродуктивное число.

- **Карантин** моделируется снижением эффективного β:
  `β_eff = β · (1 - efficiency)`.
- **Вакцинация** моделируется переносом части населения из S сразу в R
  до начала эпидемии: `S0 = N - I0 - vaccinated`, `R0_init = vaccinated`.

---

## 🇬🇧 English

### About the project
This project implements the SIR (Susceptible–Infected–Recovered)
epidemiological model in Python using an object-oriented approach
(OOP). The application lets you compare three scenarios: no
interventions, quarantine, and vaccination.

### File structure
```
project/
├── main.py          — entry point that launches the application
├── gui.py           — graphical interface built with CustomTkinter
├── sir_model.py      — SIR system of differential equations (scipy)
├── simulation.py     — module orchestrating the three scenarios
├── graphs.py         — plotting with matplotlib
├── statistics.py     — statistical indicators calculation
├── utils.py          — trilingual dictionary and helper functions
├── assets/           — additional resources (icons, etc.)
└── README.md         — this file
```

### Installing dependencies
```bash
pip install numpy scipy matplotlib pandas customtkinter
```
> Note: `tkinter` usually ships with Python. If missing on Linux:
> `sudo apt-get install python3-tk`

### Running
```bash
python main.py
```

### Features
- Input fields for population size, initial infected count,
  infection rate β, recovery rate γ, vaccination percentage,
  quarantine efficiency, and simulation duration;
- "Run Simulation" button to start the calculation;
- "Clear Results" button;
- Save graphs as PNG files;
- Displays infection peak, peak day, number recovered, number
  healthy, percentage infected, percentage recovered, and R0;
- S(t)/I(t)/R(t) plot and a three-scenario comparison plot;
- Interface language switch: Kazakh / Russian / English.

### Mathematical model (brief)
The classical Kermack–McKendrick SIR model is described by:

```
dS/dt = -β·S·I/N
dI/dt =  β·S·I/N - γ·I
dR/dt =  γ·I
```

where N is the population size, β is the infection rate, γ is the
recovery rate, and R0 = β/γ is the basic reproduction number.

- **Quarantine** is modeled by reducing the effective β:
  `β_eff = β · (1 - efficiency)`.
- **Vaccination** is modeled by moving part of the population from S
  directly into R before the epidemic starts:
  `S0 = N - I0 - vaccinated`, `R0_init = vaccinated`.

---

## Авторлар / Авторы / Authors
Университеттік экзаменациялық жоба «Компьютерлік модельдеу» пәні бойынша.
Университетский экзаменационный проект по дисциплине «Компьютерное моделирование».
University exam project for the "Computer Modeling" course.
