# -*- coding: utf-8 -*-
"""
sir_model.py
============
SIR (Susceptible - Infected - Recovered) эпидемиологиялық моделінің
математикалық өзегі. Дифференциалдық теңдеулер scipy.integrate.odeint
көмегімен сандық түрде шешіледі.

Математическое ядро эпидемиологической SIR-модели
(Susceptible - Infected - Recovered). Система дифференциальных
уравнений решается численно с помощью scipy.integrate.odeint.

The mathematical core of the SIR (Susceptible - Infected - Recovered)
epidemiological model. The system of differential equations is solved
numerically using scipy.integrate.odeint.

---------------------------------------------------------------------------
Теориялық негіз / Теоретическая основа / Theoretical background
---------------------------------------------------------------------------
Классикалық SIR моделі (Kermack & McKendrick, 1927) халықты үш топқа бөледі:

    S(t) - Susceptible  - әлі ауырмаған, бірақ жұғу қаупі бар адамдар
    I(t) - Infected      - қазіргі уақытта ауру жұқтырған адамдар
    R(t) - Recovered     - жазылған немесе иммунитеті бар адамдар

Дифференциалдық теңдеулер жүйесі:

    dS/dt = -β * S * I / N
    dI/dt =  β * S * I / N  -  γ * I
    dR/dt =  γ * I

мұндағы:
    N      - жалпы халық саны (S + I + R = N = const)
    β (бета) - жұқтыру коэффициенті (бір адамның бірлік уақытта
               қанша адамды жұқтыратынын сипаттайды)
    γ (гамма) - жазылу коэффициенті (1/γ - ауру ұзақтығына тең)
    R0 = β / γ - негізгі репродукциялық сан (бір науқас орта есеппен
               қанша адамды жұқтырады)

Аналогично на русском: классическая SIR-модель делит популяцию на три
группы (восприимчивые, заражённые, выздоровевшие) и описывает переход
между ними системой из трёх обыкновенных дифференциальных уравнений
первого порядка, приведённой выше.
"""

from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from scipy.integrate import odeint


@dataclass
class SIRParameters:
    """
    Модель параметрлерінің контейнері (dataclass).
    Контейнер параметров модели.
    Container for the model's input parameters.
    """
    population: float          # N - жалпы халық саны / общая численность / total population
    initial_infected: float    # I0 - бастапқы жұқтырғандар / начальные заражённые / initial infected
    beta: float                # β - жұқтыру коэффициенті / коэффициент заражения / infection rate
    gamma: float                # γ - жазылу коэффициенті / коэффициент выздоровления / recovery rate
    days: int                  # модельдеу ұзақтығы / длительность / duration in days
    vaccinated_fraction: float = 0.0   # вакцинацияланғандар үлесі 0..1 / доля вакцинированных 0..1
    quarantine_efficiency: float = 0.0  # карантин тиімділігі 0..1 / эффективность карантина 0..1


class SIRModel:
    """
    SIR эпидемиологиялық моделін сандық интеграциялау класы.
    Класс для численного интегрирования эпидемиологической SIR-модели.
    Class that performs the numerical integration of the SIR epidemiological model.

    Класс үш сценарийді қолдайды:
    Класс поддерживает три сценария:
    The class supports three scenarios:

        1. "normal"      - ешбір шектеусіз / без ограничений / no interventions
        2. "quarantine"  - карантинмен (β төмендейді) / с карантином (снижается β)
                            with quarantine (β is reduced)
        3. "vaccination" - вакцинациямен (S0 азаяды) / с вакцинацией (уменьшается S0)
                            with vaccination (initial S is reduced)
    """

    def __init__(self, params: SIRParameters):
        self.params = params

    # -----------------------------------------------------------------
    # Дифференциалдық теңдеулер жүйесі / Система ДУ / ODE system
    # -----------------------------------------------------------------
    @staticmethod
    def _derivatives(y: list[float], t: float, beta: float, gamma: float, n: float) -> list[float]:
        """
        SIR жүйесінің оң жақ бөлігі (odeint үшін).
        Правая часть системы уравнений SIR (для odeint).
        Right-hand side of the SIR ODE system (used by odeint).

        dS/dt = -β*S*I/N
        dI/dt =  β*S*I/N - γ*I
        dR/dt =  γ*I
        """
        s, i, r = y
        ds_dt = -beta * s * i / n
        di_dt = beta * s * i / n - gamma * i
        dr_dt = gamma * i
        return [ds_dt, di_dt, dr_dt]

    # -----------------------------------------------------------------
    # Негізгі есептеу / Основной расчёт / Core computation
    # -----------------------------------------------------------------
    def simulate(self, scenario: str = "normal") -> dict:
        """
        Таңдалған сценарий үшін SIR теңдеулерін интегралдайды.
        Интегрирует уравнения SIR для выбранного сценария.
        Integrates the SIR equations for the chosen scenario.

        Параметрлер / Параметры / Parameters
        -------------------------------------
        scenario : str
            "normal" | "quarantine" | "vaccination"

        Қайтарады / Возвращает / Returns
        -------------------------------------
        dict {
            "t": np.ndarray - уақыт торы / временная сетка / time grid,
            "S": np.ndarray, "I": np.ndarray, "R": np.ndarray,
            "beta_eff": float - қолданылған нақты β,
            "s0": float, "i0": float, "r0_init": float
        }
        """
        n = self.params.population
        beta = self.params.beta
        gamma = self.params.gamma
        i0 = self.params.initial_infected
        s0 = n - i0
        r0_init = 0.0

        # --- Сценарийге байланысты параметрлерді түзету --------------
        # --- Корректировка параметров в зависимости от сценария ------
        # --- Adjust parameters depending on the scenario --------------
        if scenario == "quarantine":
            # Карантин науқастар арасындағы байланысты азайтады,
            # сондықтан тиімді β кемиді.
            # Карантин снижает контакты между людьми, поэтому эффективный
            # коэффициент заражения β уменьшается.
            # Quarantine reduces contact between people, so the effective
            # infection rate β is lowered.
            efficiency = min(max(self.params.quarantine_efficiency, 0.0), 1.0)
            beta = beta * (1.0 - efficiency)

        elif scenario == "vaccination":
            # Вакцинацияланған адамдар бірден "Recovered" (иммунды)
            # тобына өтеді, сондықтан бастапқы S0 азаяды, ал R0 өседі.
            # Вакцинированные сразу переходят в группу "Recovered"
            # (иммунных), поэтому начальное S0 уменьшается, а R0 растёт.
            # Vaccinated individuals move directly into the "Recovered"
            # (immune) group, so the initial S0 decreases and R0 increases.
            frac = min(max(self.params.vaccinated_fraction, 0.0), 1.0)
            vaccinated = n * frac
            s0 = max(n - i0 - vaccinated, 0.0)
            r0_init = vaccinated

        # --- Уақыт торы / Временная сетка / Time grid ------------------
        t = np.linspace(0, self.params.days, self.params.days + 1)

        # --- Бастапқы шарттар / Начальные условия / Initial conditions -
        y0 = [s0, i0, r0_init]

        # --- Теңдеулер жүйесін сандық интегралдау (Runge-Kutta негізді
        #     LSODA алгоритмі odeint ішінде қолданылады) -----------------
        # --- Численное интегрирование системы (odeint использует
        #     адаптивный алгоритм LSODA) --------------------------------
        # --- Numerically integrate the system (odeint uses the
        #     adaptive LSODA algorithm internally) ---------------------
        result = odeint(self._derivatives, y0, t, args=(beta, gamma, n))
        s, i, r = result[:, 0], result[:, 1], result[:, 2]

        return {
            "t": t,
            "S": s,
            "I": i,
            "R": r,
            "beta_eff": beta,
            "s0": s0,
            "i0": i0,
            "r0_init": r0_init,
        }

    def basic_reproduction_number(self) -> float:
        """
        R0 = β / γ негізгі репродукциялық санын есептейді.
        Вычисляет базовое репродуктивное число R0 = β / γ.
        Computes the basic reproduction number R0 = β / γ.
        """
        if self.params.gamma == 0:
            return float("inf")
        return self.params.beta / self.params.gamma
