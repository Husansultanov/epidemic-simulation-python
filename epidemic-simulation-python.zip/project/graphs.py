# -*- coding: utf-8 -*-
"""
graphs.py
=========
matplotlib арқылы SIR моделінің графиктерін салуға жауапты модуль.
Екі негізгі функцияны қамтиды: S(t)/I(t)/R(t) графигі және
үш сценарийді салыстыратын график. Tkinter/CustomTkinter ішіне
ендіру үшін FigureCanvasTkAgg қолданылады.

Модуль, отвечающий за построение графиков SIR-модели с помощью
matplotlib. Содержит две основные функции: график S(t)/I(t)/R(t)
и график сравнения трёх сценариев. Для встраивания в
Tkinter/CustomTkinter используется FigureCanvasTkAgg.

Module responsible for plotting the SIR model results with
matplotlib. It provides two main functions: the S(t)/I(t)/R(t)
plot and the three-scenario comparison plot. FigureCanvasTkAgg is
used to embed the figures inside Tkinter/CustomTkinter.
"""

from __future__ import annotations
import matplotlib
matplotlib.use("TkAgg")

import matplotlib.pyplot as plt
from matplotlib.figure import Figure

from utils import t as tr  # аударма функциясы / функция перевода / translation function

# --- Университеттік стильге сай түс палитрасы -----------------------------
# --- Цветовая палитра в академическом стиле -------------------------------
# --- Academic-style color palette -----------------------------------------
COLOR_S = "#2E86AB"        # көк / синий / blue
COLOR_I = "#E63946"        # қызыл / красный / red
COLOR_R = "#2A9D8F"        # жасыл / зелёный / green
COLOR_NORMAL = "#E63946"
COLOR_QUARANTINE = "#F4A261"
COLOR_VACCINATION = "#2A9D8F"

plt.style.use("seaborn-v0_8-whitegrid" if "seaborn-v0_8-whitegrid" in plt.style.available else "default")


class GraphPlotter:
    """
    SIR моделінің нәтижелерін бейнелеу үшін графиктер жасайтын класс.
    Класс для построения графиков по результатам SIR-модели.
    Class responsible for building graphs from the SIR model results.
    """

    def __init__(self, lang: str = "RU"):
        self.lang = lang

    def set_language(self, lang: str) -> None:
        """Ағымдағы тілді ауыстырады / переключает текущий язык / switches the current language."""
        self.lang = lang

    # -----------------------------------------------------------------
    # Негізгі S/I/R графигі / Основной график S/I/R / Main S/I/R plot
    # -----------------------------------------------------------------
    def plot_main(self, figure: Figure, sir_result: dict) -> None:
        """
        S(t), I(t), R(t) қисықтарын бір суретке (Figure) салады.
        Рисует кривые S(t), I(t), R(t) на одном объекте Figure.
        Draws the S(t), I(t), R(t) curves on a single Figure object.
        """
        figure.clear()
        ax = figure.add_subplot(111)

        t_axis = sir_result["t"]
        ax.plot(t_axis, sir_result["S"], color=COLOR_S, linewidth=2.4,
                label=tr("susceptible_label", self.lang))
        ax.plot(t_axis, sir_result["I"], color=COLOR_I, linewidth=2.4,
                label=tr("infected_label", self.lang))
        ax.plot(t_axis, sir_result["R"], color=COLOR_R, linewidth=2.4,
                label=tr("recovered_label", self.lang))

        # Шыңды белгілеу / Отметка пика / Mark the peak
        peak_idx = sir_result["I"].argmax()
        ax.scatter([t_axis[peak_idx]], [sir_result["I"][peak_idx]],
                   color=COLOR_I, zorder=5, s=60, edgecolor="black")

        ax.set_title(tr("main_title", self.lang), fontsize=13, fontweight="bold")
        ax.set_xlabel(tr("days_axis", self.lang), fontsize=11)
        ax.set_ylabel(tr("people_axis", self.lang), fontsize=11)
        ax.legend(loc="upper right", frameon=True)
        ax.grid(alpha=0.3)
        figure.tight_layout()

    # -----------------------------------------------------------------
    # Салыстыру графигі / График сравнения / Comparison plot
    # -----------------------------------------------------------------
    def plot_comparison(self, figure: Figure, results: dict[str, dict]) -> None:
        """
        Үш сценарийдің I(t) қисықтарын бір суретке салыстыра салады.
        Рисует кривые I(t) трёх сценариев для сравнения на одном графике.
        Draws the I(t) curves of all three scenarios together for comparison.
        """
        figure.clear()
        ax = figure.add_subplot(111)

        style_map = {
            "normal": (COLOR_NORMAL, tr("scenario_normal", self.lang), "-"),
            "quarantine": (COLOR_QUARANTINE, tr("scenario_quarantine", self.lang), "--"),
            "vaccination": (COLOR_VACCINATION, tr("scenario_vaccination", self.lang), "-."),
        }

        for scenario, result in results.items():
            color, label, linestyle = style_map.get(scenario, ("gray", scenario, "-"))
            ax.plot(result["t"], result["I"], color=color, linewidth=2.4,
                    linestyle=linestyle, label=label)

        ax.set_title(tr("comparison_title", self.lang), fontsize=13, fontweight="bold")
        ax.set_xlabel(tr("days_axis", self.lang), fontsize=11)
        ax.set_ylabel(tr("people_axis", self.lang), fontsize=11)
        ax.legend(loc="upper right", frameon=True)
        ax.grid(alpha=0.3)
        figure.tight_layout()

    # -----------------------------------------------------------------
    # Файлға сақтау / Сохранение в файл / Saving to file
    # -----------------------------------------------------------------
    @staticmethod
    def save_figure(figure: Figure, filepath: str, dpi: int = 200) -> None:
        """
        Берілген Figure нысанын PNG файлына сақтайды.
        Сохраняет заданный объект Figure в файл PNG.
        Saves the given Figure object to a PNG file.
        """
        figure.savefig(filepath, dpi=dpi, bbox_inches="tight")
