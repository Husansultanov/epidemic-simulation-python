# -*- coding: utf-8 -*-
"""
simulation.py
=============
Бірнеше сценарийді (қалыпты, карантин, вакцинация) басқаратын
жоғары деңгейлі модуль. SIRModel класын пайдаланады және
барлық сценарийлердің нәтижелерін бір жерде жинайды.

Модуль верхнего уровня, управляющий несколькими сценариями
(обычный, карантин, вакцинация). Использует класс SIRModel и
собирает результаты всех сценариев в одном месте.

High-level module that orchestrates several scenarios (baseline,
quarantine, vaccination). It uses the SIRModel class and collects
the results of every scenario in one place.
"""

from __future__ import annotations
from dataclasses import dataclass

from sir_model import SIRModel, SIRParameters


@dataclass
class SimulationInput:
    """
    Пайдаланушыдан алынған шикі енгізу деректері.
    Сырые входные данные, полученные от пользователя.
    Raw input data collected from the user interface.
    """
    population: float
    initial_infected: float
    beta: float
    gamma: float
    vaccination_pct: float       # 0..100
    quarantine_eff_pct: float    # 0..100
    days: int


class Simulation:
    """
    SIR моделін үш түрлі сценарий бойынша іске қосатын менеджер-класс.
    Класс-менеджер, запускающий SIR-модель по трём сценариям.
    Manager class that runs the SIR model across three scenarios.
    """

    SCENARIOS = ("normal", "quarantine", "vaccination")

    def __init__(self, sim_input: SimulationInput):
        self.sim_input = sim_input
        self._params = self._build_parameters(sim_input)
        self._model = SIRModel(self._params)
        self.results: dict[str, dict] = {}

    @staticmethod
    def _build_parameters(sim_input: SimulationInput) -> SIRParameters:
        """
        SimulationInput нысанын SIRParameters нысанына түрлендіреді
        (мысалы, пайыздарды 0..1 диапазонына түрлендіру).

        Преобразует SimulationInput в SIRParameters (например,
        конвертирует проценты в диапазон 0..1).

        Converts a SimulationInput object into SIRParameters
        (e.g. converts percentages into the 0..1 range).
        """
        return SIRParameters(
            population=sim_input.population,
            initial_infected=sim_input.initial_infected,
            beta=sim_input.beta,
            gamma=sim_input.gamma,
            days=sim_input.days,
            vaccinated_fraction=sim_input.vaccination_pct / 100.0,
            quarantine_efficiency=sim_input.quarantine_eff_pct / 100.0,
        )

    def run_all(self) -> dict[str, dict]:
        """
        Барлық үш сценарийді дәйекті түрде есептейді.
        Последовательно рассчитывает все три сценария.
        Sequentially computes all three scenarios.

        Қайтарады / Возвращает / Returns:
            dict {scenario_name: simulate()-нәтижесі}
        """
        self.results = {
            scenario: self._model.simulate(scenario=scenario)
            for scenario in self.SCENARIOS
        }
        return self.results

    def get_result(self, scenario: str) -> dict:
        """
        Нақты сценарийдің есептелген нәтижесін қайтарады.
        Возвращает рассчитанный результат конкретного сценария.
        Returns the computed result for a specific scenario.
        """
        if scenario not in self.results:
            raise KeyError(f"Scenario '{scenario}' has not been computed yet.")
        return self.results[scenario]

    def basic_reproduction_number(self) -> float:
        """
        Ағымдағы параметрлер үшін R0 санын қайтарады.
        Возвращает число R0 для текущих параметров.
        Returns R0 for the current parameters.
        """
        return self._model.basic_reproduction_number()
